#!/usr/bin/env python
#coding=utf-8
import rospy,tf,math
from geometry_msgs.msg import PoseStamped

def publisher():
    rospy.init_node("M_Publisher")
    pub=rospy.Publisher("/M_Pose",PoseStamped,queue_size=1)
    rate=rospy.Rate(1)
    while not rospy.is_shutdown():
        p=PoseStamped()
        p.header.frame_id="world"
        p.header.stamp=rospy.Time.now()
        p.pose.position.x=1
        p.pose.position.y=1
        p.pose.position.z=1

        q=tf.transformations.quaternion_from_euler(0,0,0)
        p.pose.orientation.x=q[0]
        p.pose.orientation.y=q[1]
        p.pose.orientation.z=q[2]
        p.pose.orientation.w=q[3]

        pub.publish(p)

        br=tf.TransformBroadcaster()
        br.sendTransform((1,1,1),
        tf.transformations.quaternion_from_euler(math.radians(0),
        math.radians(0),math.radians(0)),rospy.Time.now(),"M_TF","world")
        rospy.loginfo("M_Pose Published!qwq")
        rate.sleep()
publisher()
