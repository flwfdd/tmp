#!/usr/bin/env python
#coding=utf-8
import rospy,tf,math
from geometry_msgs.msg import PoseStamped

def handler(pm):
    listener=tf.TransformListener()
    while True:
        try:
            (trans,rot)=listener.lookupTransform("/A2B","/M_TF",rospy.Time(0))
            p=PoseStamped()
            p.header.frame_id="A2B"
            p.header.stamp=rospy.Time.now()
            p.pose.position.x=trans[0]
            p.pose.position.y=trans[1]
            p.pose.position.z=trans[2]

            p.pose.orientation.x=rot[0]
            p.pose.orientation.y=rot[1]
            p.pose.orientation.z=rot[2]
            p.pose.orientation.w=rot[3]

            pub.publish(p)
            br=tf.TransformBroadcaster()
            br.sendTransform(trans,rot,rospy.Time.now(),"N_TF","A2B")
            rospy.loginfo("N_Pose Published!qwq")
            break
        except: continue

rospy.init_node("N_Publisher")
pub=rospy.Publisher("/N_Pose",PoseStamped,queue_size=1)
rospy.Subscriber("/M_Pose",PoseStamped,handler)
rospy.spin()
    
