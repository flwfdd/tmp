#!/usr/bin/env python
#coding=utf-8
import rospy,math,tf
from geometry_msgs.msg import PoseStamped

def Br():
    br=tf.TransformBroadcaster()
    br.sendTransform((3,-2,0),
        tf.transformations.quaternion_from_euler(math.radians(-90),
        math.radians(30),math.radians(45)),rospy.Time.now(),"A2B","world")
    rospy.loginfo("A2B UPDATE")

rospy.init_node("A2B")
rate=rospy.Rate(10)
while not rospy.is_shutdown():
    Br()
    rate.sleep()
